from ScraperFC.FBRef import FBRef
from ScraperFC.FiveThirtyEight import FiveThirtyEight
from ScraperFC.ScraperFC import ScraperFC
from ScraperFC.Understat import Understat
from ScraperFC.shared_functions import *