from ScraperFC.FBRef import FBRef
from ScraperFC.FiveThirtyEight import FiveThirtyEight
from ScraperFC.ScraperFC import ScraperFC
from ScraperFC.Understat import Understat
from ScraperFC.SofaScore import SofaScore
from ScraperFC.WhoScored import WhoScored
from ScraperFC.shared_functions import *