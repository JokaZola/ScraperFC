from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
import time
from IPython.display import clear_output
from ScraperFC.shared_functions import check_season


class WhoScored():
    
    def __init__(self):
        options = Options()
        # options.headless = True
        options.add_argument("window-size=1400,600")
        self.driver = webdriver.Chrome(ChromeDriverManager().install(), options=options)
        clear_output()


    def close(self):
        self.driver.close()
        self.driver.quit()


    def get_season_link(self, year, league):
        links = {
            "EPL": "https://www.whoscored.com/Regions/252/Tournaments/2/England-Premier-League",
            "La Liga": "https://www.whoscored.com/Regions/206/Tournaments/4/Spain-LaLiga",
            "Bundesliga": "https://www.whoscored.com/Regions/81/Tournaments/3/Germany-Bundesliga",
            "Serie A": "https://www.whoscored.com/Regions/108/Tournaments/5/Italy-Serie-A",
            "Ligue 1": "https://www.whoscored.com/Regions/74/Tournaments/22/France-Ligue-1"
        }
        year_str = "{}/{}".format(year-1, year)

        self.driver.get(links[league])

        for el in self.driver.find_elements_by_tag_name("select"):
            if el.get_attribute("id") == "seasons":

                for subel in el.find_elements_by_tag_name("option"):
                    if subel.text == year_str:
                        return "https://www.whoscored.com"+subel.get_attribute("value")
        return -1



    def get_match_links(self, year, league):
        # Go to season page
        self.driver.get(self.get_season_link(year, league))
        time.sleep(1)
        
        # Go to fixtures page
        for el in self.driver.find_elements_by_tag_name("a"):
            if el.text == "Fixtures":
                el.click()
                break
        time.sleep(1)

        # Get button to prev month matches
        prev_button = None
        for el in self.driver.find_elements_by_tag_name("a"):
            if "previous button ui-state-default" in el.get_attribute("class"):
                prev_button = el
        if not prev_button:
            return -1

        # Gather the links
        done = False
        links = set()
        while not done:
            # Get match links of curr month
            for el in self.driver.find_elements_by_tag_name("a"):
                if el.get_attribute("class") == "result-1 rc":
                    links.add(el.get_attribute("href"))

            # Keep going to previous month, if not data available
            if prev_button.get_attribute("title") == "No data for previous month":
                done = True
            else:
                prev_button.click()
                time.sleep(1)
        return list(links)


    def scrape_matches(self, year, league):
        error, valid = check_season(year, league, "WhoScored")
        if not valid:
            print(error)
            return -1
        
        links = self.get_match_links(year, league)

        for link in links:
            print(link)
            match_data = self.scrape_match(link)
            return match_data


    def scrape_match(self, link):
        self.driver.get(link)
        # for el in self.driver.find_elements_by_tag_name("script"):
        #     print(el)
        # return 999
        return self.driver.page_source
